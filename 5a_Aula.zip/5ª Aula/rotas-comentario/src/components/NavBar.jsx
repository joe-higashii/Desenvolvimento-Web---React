import { Link } from "react-router-dom"

const NavBar = () => {
    return (
        <>
            <Link>Teste</Link>
        </>
    )
}

export default NavBar