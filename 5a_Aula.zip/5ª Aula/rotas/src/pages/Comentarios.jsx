import NavBar from "../components/NavBar"

const Comentarios = () => {
    return (
        <>
            <h1>Comentários</h1>
        </>
    )
}

export default Comentarios