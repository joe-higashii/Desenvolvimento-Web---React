import NavBar from "../components/NavBar"

const Contato = () => {
    return (
        <>
        <div>            
            <h2>Entre em contato consco</h2>
            <p>raphaelrochap@gmail.com</p>
        </div>
        </>
    )
}

export default Contato